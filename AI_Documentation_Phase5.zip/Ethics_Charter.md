
# Ethics & Consent Charter

No surveillance. No identity tracking. Human-in-the-loop. Transparency by design.
