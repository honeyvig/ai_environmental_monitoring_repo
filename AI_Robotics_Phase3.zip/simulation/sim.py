
def run_sim():
    print("Simulation running")
