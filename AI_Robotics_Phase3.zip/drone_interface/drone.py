
def scout():
    print("Drone scouting area")
