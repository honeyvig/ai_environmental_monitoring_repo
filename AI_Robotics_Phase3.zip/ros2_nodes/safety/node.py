
# ROS2 Safety Controller
def emergency_stop():
    print("Emergency stop activated")
