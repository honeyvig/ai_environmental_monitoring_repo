
# ROS2 Sensor Node Placeholder
def read_sensors():
    return {"thermal": False, "air": "LOW"}
