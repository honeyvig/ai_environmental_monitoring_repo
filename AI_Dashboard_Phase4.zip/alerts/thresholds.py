
def check_alerts(data):
    if data.get("pm25",0) > 100:
        return "ALERT"
    return "OK"
