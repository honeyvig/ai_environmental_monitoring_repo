
def generate_report(data):
    return f"Environmental Report: {data}"
