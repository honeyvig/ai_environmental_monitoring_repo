
def detect_humans(frame):
    '''
    Placeholder for YOLO-based human silhouette detection.
    No identity, no facial features.
    '''
    return [{"bbox":[0,0,100,200], "confidence":0.85}]
