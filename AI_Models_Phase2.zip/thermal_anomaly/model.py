
def detect_anomaly(thermal_frame):
    '''
    Detects abnormal heat patterns for safety monitoring.
    '''
    return {"anomaly": False, "score": 0.12}
