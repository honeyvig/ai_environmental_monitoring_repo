
# Phase 2 – AI Models (Ethical & Safe)

This package contains AI model scaffolding for:
- Human silhouette detection (no face recognition)
- Thermal anomaly detection
- Air quality risk classification

Models are designed for humanitarian, environmental, and safety use.
