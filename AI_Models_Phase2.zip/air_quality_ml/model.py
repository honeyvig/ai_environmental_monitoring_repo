
def classify_risk(sensor_data):
    '''
    Classifies air quality risk levels.
    '''
    pm25 = sensor_data.get("pm25", 0)
    if pm25 > 100:
        return "HIGH"
    elif pm25 > 50:
        return "MEDIUM"
    return "LOW"
