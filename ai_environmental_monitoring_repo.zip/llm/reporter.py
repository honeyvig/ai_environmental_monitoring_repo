def generate_report(env, humans):
    return f"Env: {env}\nHumans: {humans}"
