def detect_humans():
    return [{"confidence":0.9,"zone":"A"}]
