import random
def read_environment():
    return {"temperature": 25+random.random(), "pm25": random.random()*100}
